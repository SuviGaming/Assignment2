﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment2
{
    public partial class Form1 : Form
    {
        Double value = 0;
        String math = "";
        bool math_pressed = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, EventArgs e)
        {
            if ((result.Text == "0") || (math_pressed))
                result.Clear();
            math_pressed = false;
            Button label = (Button)sender;
            result.Text = result.Text + label.Text;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            result.Text = "0";
        }

        private void math_Click(object sender, EventArgs e)
        {
            Button label = (Button)sender;
            math = label.Text;
            value = Double.Parse(result.Text);
            math_pressed = true;
            handling.Text = value + " " + math;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            handling.Text = "";
            switch (math)
            {
                case "+":
                    result.Text = (value + Double.Parse(result.Text)).ToString();
                    break;
                case "-":
                    result.Text = (value - Double.Parse(result.Text)).ToString();
                    break;
                case "/":
                    result.Text = (value / Double.Parse(result.Text)).ToString();
                    break;
                case "*":
                    result.Text = (value * Double.Parse(result.Text)).ToString();
                    break;
                default:
                    break;
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            result.Clear();
            value = 0;
        }

        private void backspace_Click(object sender, EventArgs e)
        {
            if (result.Text.Length > 0)
            {
                result.Text = result.Text.Remove(result.Text.Length - 1, 1);
            }

            if (result.Text == "")
            {
                result.Text = "0";
            }
        }

        private void PM_Click(object sender, EventArgs e)
        {
            if (result.Text.Contains("-"))
            {
                result.Text = result.Text.Remove(0, 1);
            }
            else
            {
                result.Text = "-" + result.Text;
            }
        }

        private void square_Click(object sender, EventArgs e)
        {
            handling.Text = "";
            double sq = Double.Parse(result.Text);
            handling.Text = System.Convert.ToString("log" + "(" + (result.Text) + ")");
            sq = Math.Sqrt(sq);
            result.Text = System.Convert.ToString(sq);
        }

        private void recip_Click(object sender, EventArgs e)
        {
            Double r;
            r = Convert.ToDouble(1.0 / Convert.ToDouble(result.Text));
            result.Text = System.Convert.ToString(r);
        }

        private void result_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 27)
            {
                ((TextBox)sender).Clear();
            }

            if (e.KeyChar == 8)
            {
                result.Text = result.Text.Remove(result.Text.Length - 1, 1);
            }

            if (result.Text == "")
            {
                result.Text = "0";
            }
        }
    }
}
